<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Registrar Quehacer Completado</title>
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<header>
    <h1>Registrar Quehacer Completado</h1>
    <nav>
        <a href="../index.jsp">Volver al Tablero</a>
    </nav>
</header>
<div class="container">
    <form action="quehaceres" method="post">
        <input type="hidden" name="action" value="markComplete" />
        <fieldset>
            <label for="miembroId">Seleccionar Miembro:</label>
            <select id="miembroId" name="miembroId" required>
                <c:forEach var="miembro" items="${listaMiembros}">
                    <option value="${miembro.id}">${miembro.nombre}</option>
                </c:forEach>
            </select>
        </fieldset>
        <fieldset>
            <label for="quehacerId">Seleccionar Quehacer:</label>
            <select id="quehacerId" name="quehacerId" required>
                <c:forEach var="quehacer" items="${listaQuehaceres}">
                    <option value="${quehacer.id}">${quehacer.nombre}</option>
                </c:forEach>
            </select>
        </fieldset>
        <fieldset>
            <label for="fechaFinalizacion">Fecha de Finalización:</label>
            <input type="datetime-local" id="fechaFinalizacion" name="fechaFinalizacion" required />
        </fieldset>
        <button type="submit">Tarea Terminada</button>
    </form>
</div>
</body>
</html>
