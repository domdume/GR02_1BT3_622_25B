<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Establecer Quehacer</title>
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<header>
    <h1>Establecer Quehacer</h1>
    <nav>
        <a href="../index.jsp">Volver al Tablero</a>
    </nav>
</header>
<div class="container">
    <form action="quehaceres" method="post">
        <input type="hidden" name="action" value="insert" />
        <fieldset>
            <label for="nombre">Nombre del Quehacer:</label>
            <input type="text" id="nombre" name="nombre" required />
        </fieldset>
        <fieldset>
            <label for="tiempoLimite">Fecha Límite:</label>
            <input type="datetime-local" id="tiempoLimite" name="tiempoLimite" required />
        </fieldset>
        <fieldset>
            <label for="miembroId">Asignado a:</label>
            <select id="miembroId" name="miembroId" required>
                <c:forEach var="miembro" items="${listaMiembros}">
                    <option value="${miembro.id}">${miembro.nombre}</option>
                </c:forEach>
                <c:if test="${empty listaMiembros}">
                    <option disabled>No hay miembros disponibles</option>
                </c:if>
            </select>
        </fieldset>
        <button type="submit">Agregar Quehacer</button>
    </form>
    <c:if test="${not empty errorMessage}">
        <p style="color: red;">${errorMessage}</p>
    </c:if>
</div>
</body>
</html>