<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Revisar Quehaceres Pendientes</title>
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<header>
    <h1>Revisar Quehaceres Pendientes</h1>
    <nav>
        <a href="../index.jsp">Volver al Tablero</a>
    </nav>
</header>
<div class="container">
    <form action="quehaceres" method="get">
        <fieldset>
            <label for="miembroId">Seleccionar Miembro:</label>
            <select id="miembroId" name="miembroId" required>
                <c:forEach var="miembro" items="${listaMiembros}">
                    <option value="${miembro.id}">${miembro.nombre}</option>
                </c:forEach>
            </select>
        </fieldset>
        <button type="submit">Ver Tareas Pendientes</button>
    </form>
    <h2>Tareas Pendientes</h2>
    <table>
        <thead>
            <tr>
                <th>Quehacer</th>
                <th>Fecha Límite</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach var="quehacer" items="${tareasPendientes}">
                <tr>
                    <td>${quehacer.nombre}</td>
                    <td>${quehacer.tiempoLimite}</td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
    <c:if test="${empty tareasPendientes}">
        <p>¡Felicidades, no tienes tareas pendientes!</p>
    </c:if>
</div>
</body>
</html>