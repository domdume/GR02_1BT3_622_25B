<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Tablero del Hogar</title>
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<header>
    <h1>Tablero del Hogar</h1>
    <nav>
        <a href="${pageContext.request.contextPath}/miembros/form.jsp">Registrar Miembro</a>
        <a href="${pageContext.request.contextPath}/quehaceres/form.jsp">Establecer Quehacer</a>
        <a href="${pageContext.request.contextPath}/quehaceres/complete.jsp">Registrar Quehacer Completado</a>
        <a href="${pageContext.request.contextPath}/quehaceres/pending.jsp">Revisar Quehaceres Pendientes</a>
    </nav>
</header>
<div class="container">
    <h2>Quehaceres del Hogar</h2>
    <table>
        <thead>
            <tr>
                <th>Nombre del Quehacer</th>
                <th>Asignado a</th>
                <th>Fecha Límite</th>
                <th>Estado</th>
                <th>Recompensa / Penalización</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach var="q" items="${listaQuehaceres}">
                <tr class="${q.estadoFinalizado ? (q.estadoCompletado ? 'completed' : 'overdue') : ''}">
                    <td>${q.nombre}</td>
                    <td>${q.miembroHogar.nombre}</td>
                    <td>${q.tiempoLimite}</td>
                    <td>${q.estadoFinalizado ? (q.estadoCompletado ? 'Completado' : 'Atrasado') : 'Pendiente'}</td>
                    <td>${q.estadoFinalizado ? (q.estadoCompletado ? q.recompensa : q.penalizacion) : 'Sin asignar'}</td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</div>
</body>
</html>