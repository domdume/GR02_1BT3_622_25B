package servlet;

import dao.MiembroHogarDAO;
import dao.QuehacerDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Dificultad;
import model.MiembroHogar;
import model.Quehacer;
import model.Incentivo;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

@WebServlet(name = "QuehacerServlet", value = "/quehaceres")
public class QuehacerServlet extends HttpServlet {
    private QuehacerDAO quehacerDAO;
    private MiembroHogarDAO miembroHogarDAO;

    private static final Logger logger = Logger.getLogger(QuehacerServlet.class.getName());

    @Override
    public void init() {
        quehacerDAO = new QuehacerDAO();
        miembroHogarDAO = new MiembroHogarDAO();

        testFindAllMiembros();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "new":
                showNewForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deleteQuehacer(request, response);
                break;
            case "listGestion":
                listGestionQuehaceres(request, response);
                break;
            default:
                listQuehaceres(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "insert":
                insertQuehacer(request, response);
                break;
            case "update":
                updateQuehacer(request, response);
                break;
            default:
                listQuehaceres(request, response);
                break;
        }
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<MiembroHogar> listaMiembros = miembroHogarDAO.findAll(); // Cargar miembros desde la BD
        logger.info("Lista de miembros recuperada: " + listaMiembros);

        if (listaMiembros.isEmpty()) {
            logger.warning("No hay miembros disponibles para asignar quehaceres.");
            request.getSession().setAttribute("errorMessage", "No hay miembros disponibles para asignar quehaceres.");
        } else {
            logger.info("Miembros disponibles: " + listaMiembros.size());
            request.getSession().removeAttribute("errorMessage"); // Eliminar mensaje de error si hay miembros
        }

        request.setAttribute("listaMiembros", listaMiembros); // Pasar miembros al JSP
        request.setAttribute("dificultades", Dificultad.values()); // Pasar dificultades al JSP
        request.getRequestDispatcher("/quehaceres/form.jsp").forward(request, response); // Redirigir al JSP
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        Quehacer quehacerExistente = quehacerDAO.findById(id);
        List<MiembroHogar> listaMiembros = miembroHogarDAO.findAll();
        request.setAttribute("quehacer", quehacerExistente);
        request.setAttribute("listaMiembros", listaMiembros);
        request.setAttribute("dificultades", Dificultad.values());
        request.setAttribute("action", "update");
        request.getRequestDispatcher("/quehaceres/form.jsp").forward(request, response);
    }

    private void insertQuehacer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String nombre = request.getParameter("nombre");
        String dificultad = request.getParameter("dificultad");
        String tiempoLimiteStr = request.getParameter("tiempoLimite");
        String miembroIdStr = request.getParameter("miembroId");

        try {
            Long miembroId = Long.parseLong(miembroIdStr);
            MiembroHogar miembro = miembroHogarDAO.findById(miembroId);
            Dificultad dif = Dificultad.valueOf(dificultad);
            LocalDateTime tiempoLimite = LocalDateTime.parse(tiempoLimiteStr);

            Quehacer nuevoQuehacer = new Quehacer(nombre, dif, tiempoLimite);
            nuevoQuehacer.setMiembroHogar(miembro);

            quehacerDAO.create(nuevoQuehacer);
            request.getSession().setAttribute("successMessage", "Quehacer agregado correctamente.");
        } catch (Exception e) {
            request.getSession().setAttribute("errorMessage", "Error al agregar el quehacer.");
        }

        response.sendRedirect(request.getContextPath() + "/quehaceres?action=listGestion");
    }

    private void updateQuehacer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        String nombre = request.getParameter("nombre");
        String dificultad = request.getParameter("dificultad");
        String tiempoLimiteStr = request.getParameter("tiempoLimite");
        String miembroIdStr = request.getParameter("miembroId");
        String recompensa = request.getParameter("recompensa");
        String penalizacion = request.getParameter("penalizacion");

        Long miembroId = Long.parseLong(miembroIdStr);
        MiembroHogar miembro = miembroHogarDAO.findById(miembroId);
        Dificultad dif = Dificultad.valueOf(dificultad);
        LocalDateTime tiempoLimite = LocalDateTime.parse(tiempoLimiteStr);

        Quehacer quehacer = quehacerDAO.findById(id);
        quehacer.setNombre(nombre);
        quehacer.setDificultad(dif);
        quehacer.setTiempoLimite(tiempoLimite);
        quehacer.setMiembroHogar(miembro);
        quehacer.setRecompensa(recompensa);
        quehacer.setPenalizacion(penalizacion);

        quehacerDAO.update(quehacer);
        response.sendRedirect(request.getContextPath() + "/quehaceres?action=listGestion");
    }

    private void deleteQuehacer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        quehacerDAO.delete(id);
        response.sendRedirect(request.getContextPath() + "/quehaceres?action=listGestion");
    }

    private void listQuehaceres(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Quehacer> listaQuehaceres = quehacerDAO.findAllWithMiembroHogar();
        request.setAttribute("listaQuehaceres", listaQuehaceres);
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }

    private void listGestionQuehaceres(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Quehacer> listaQuehaceres = quehacerDAO.findAllWithMiembroHogar(); // Cargar quehaceres
        request.setAttribute("listaQuehaceres", listaQuehaceres); // Pasar quehaceres al JSP
        request.getRequestDispatcher("/quehaceres/index.jsp").forward(request, response);
    }

    private void markComplete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        Quehacer quehacer = quehacerDAO.findById(id);

        if (quehacer == null) {
            request.getSession().setAttribute("errorMessage", "Quehacer no encontrado");
            response.sendRedirect(request.getContextPath() + "/quehaceres?action=listGestion");
            return;
        }

        List<String> listaRecompensas = List.of("5 puntos", "10 puntos", "Medalla de honor");
        List<String> listaPenalizaciones = List.of("Sin recompensa", "Prioridad en futuras tareas");

        if (LocalDateTime.now().isAfter(quehacer.getTiempoLimite())) {
            quehacer.setEstadoFinalizado(true);
            quehacer.setPenalizacion(listaPenalizaciones.get(new Random().nextInt(listaPenalizaciones.size())));
        } else {
            quehacer.setEstadoCompletado(true);
            quehacer.setRecompensa(listaRecompensas.get(new Random().nextInt(listaRecompensas.size())));
        }

        quehacerDAO.update(quehacer);
        response.sendRedirect(request.getContextPath() + "/quehaceres?action=listGestion");
    }

    public void testFindAllMiembros() {
        List<MiembroHogar> listaMiembros = miembroHogarDAO.findAll();
        logger.info("Resultados de findAll: " + listaMiembros);
    }
}

