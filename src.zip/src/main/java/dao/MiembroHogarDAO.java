package dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import model.MiembroHogar;
import util.JPAUtil;

import java.util.ArrayList;
import java.util.List;

public class MiembroHogarDAO {

    public void create(MiembroHogar miembro) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(miembro);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public MiembroHogar findById(Long id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.createQuery("SELECT m FROM MiembroHogar m LEFT JOIN FETCH m.quehaceres WHERE m.id = :id", MiembroHogar.class)
                     .setParameter("id", id)
                     .getSingleResult();
        } catch (Exception e) {
            return null;
        } finally {
            em.close();
        }
    }

    public List<MiembroHogar> findAll() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            List<MiembroHogar> miembros = em.createQuery("SELECT m FROM MiembroHogar m", MiembroHogar.class).getResultList();
            System.out.println("Miembros recuperados: " + miembros);
            return miembros;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al recuperar miembros: " + e.getMessage());
            return new ArrayList<>(); // Devuelve una lista vacía en caso de error
        } finally {
            em.close();
        }
    }

    public void update(MiembroHogar miembro) {
        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            if (miembro != null) {
                em.merge(miembro);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    public void delete(Long id) {
        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            MiembroHogar miembro = em.find(MiembroHogar.class, id);
            if (miembro != null) {
                em.remove(miembro);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}
